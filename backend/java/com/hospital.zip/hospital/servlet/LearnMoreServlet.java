package com.zhang.hospital.servlet;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class LearnMoreServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 通过 RequestDispatcher 转发到 learnmore.jsp
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/learnmore.jsp");
        dispatcher.forward(request, response);
    }
}
